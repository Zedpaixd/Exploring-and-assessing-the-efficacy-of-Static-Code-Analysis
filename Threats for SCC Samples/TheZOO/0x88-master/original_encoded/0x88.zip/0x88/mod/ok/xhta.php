<object data="mod/ok/enter.php"></object>

