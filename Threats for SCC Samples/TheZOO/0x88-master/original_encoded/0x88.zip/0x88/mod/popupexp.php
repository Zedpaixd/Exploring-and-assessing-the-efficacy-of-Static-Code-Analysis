<?php
include("mod/popup/wscript.php"); echo'<br>';
include("mod/popup/bh.php"); echo'<br>';
include("mod/popup/xmlhttp.php"); echo'<br>';
?>