<html>
<head>
        <style>
                * {CURSOR: url("mod/ok/ani/ani.anr")}
        </style>
</head>
</html>
