<?php
sleep(2);
header("Status: 302");
header("Location: URL:res://shdoclc.dll/HTTP_501.htm");
?>