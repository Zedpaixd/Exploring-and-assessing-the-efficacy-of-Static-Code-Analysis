<script>
var w=window.open("mod/popup/bh/bh.html","_blank","height=5,width=5,left=10000,top=10000");
setInterval("w.close()",15000);
</script>